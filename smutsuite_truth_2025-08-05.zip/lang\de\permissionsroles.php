<?php

return [
    'permission_attach_success' => 'Berechtigung hinzugefügt.',
    'permission_detach_success' => 'Berechtigung entfernt.',
    'permission_already_attached' => 'Berechtigung ist bereits hinzugefügt.',
    'permission_not_attached' => 'Berechtigung ist dem Benutzer nicht zugewiesen.',
    'role_attach_success' => 'Rolle hinzugefügt.',
    'role_detach_success' => 'Rolle entfernt.',
    'role_not_found' => 'Rolle nicht gefunden.',
    'bulk_assign_success' => 'Rollen und Berechtigungen erfolgreich zugewiesen.',
    'bulk_remove_success' => 'Rollen und Berechtigungen erfolgreich entfernt.',
];
