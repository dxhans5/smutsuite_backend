<?php

return [
    'no_active_identity' => 'Nenhuma identidade ativa selecionada.',
    'forbidden'          => 'Você não tem autorização para realizar esta ação.',
    'not_found'          => 'O recurso solicitado não foi encontrado.',
    'server_error'       => 'Algo deu errado. Por favor, tente novamente.',
];
