<?php

return [
    'public_updated' => 'Öffentliches Profil aktualisiert.',
    'private_updated' => 'Privates Profil aktualisiert.',
    'fetched' => 'Profil erfolgreich abgerufen.',
];
