<?php

return [
    'permission_attach_success'   => 'Autorisation attribuée.',
    'permission_detach_success'   => 'Autorisation retirée.',
    'permission_already_attached' => 'Autorisation déjà attribuée.',
    'permission_not_attached'     => 'Autorisation introuvable pour l’utilisateur.',
    'role_attach_success'         => 'Rôle attribué.',
    'role_detach_success'         => 'Rôle retiré.',
    'role_not_found'              => 'Rôle introuvable.',
    'bulk_assign_success'         => 'Rôles et autorisations attribués avec succès.',
    'bulk_remove_success'         => 'Rôles et autorisations retirés avec succès.',
];
