<?php

return [
    'registered'              => 'Konto erfolgreich erstellt.',
    'logged_in'               => 'Erfolgreich angemeldet.',
    'logged_out'              => 'Erfolgreich abgemeldet.',
    'email_verification_sent' => 'Bestätigungs-E-Mail gesendet.',
    'email_verified'          => 'E-Mail-Adresse wurde erfolgreich verifiziert.',
    'invalid_credentials'     => 'Diese Anmeldedaten stimmen nicht mit unseren Unterlagen überein.',
    'unauthenticated'         => 'Nicht authentifiziert.',
];
