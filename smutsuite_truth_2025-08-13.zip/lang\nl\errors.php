<?php

return [
    'no_active_identity' => 'Geen actieve identiteit geselecteerd.',
    'forbidden'          => 'Je bent niet gemachtigd om deze actie uit te voeren.',
    'not_found'          => 'De opgevraagde resource is niet gevonden.',
    'server_error'       => 'Er is iets misgegaan. Probeer het opnieuw.',
];
