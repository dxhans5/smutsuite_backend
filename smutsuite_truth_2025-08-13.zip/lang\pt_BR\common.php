<?php

return [
    'save'   => 'Salvar',
    'cancel' => 'Cancelar',
    'delete' => 'Excluir',
    'edit'   => 'Editar',
    'update' => 'Atualizar',
    'create' => 'Criar',
    'back'   => 'Voltar',
    'search' => 'Pesquisar',
    'loading'=> 'Carregando...',
    'success'=> 'Sucesso',
    'error'  => 'Erro',
];
