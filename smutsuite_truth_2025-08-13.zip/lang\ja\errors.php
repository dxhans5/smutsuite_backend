<?php

return [
    'no_active_identity' => 'アクティブなアイデンティティが選択されていません。',
    'forbidden'          => 'この操作を行う権限がありません。',
    'not_found'          => '要求されたリソースが見つかりませんでした。',
    'server_error'       => '問題が発生しました。もう一度お試しください。',
];
