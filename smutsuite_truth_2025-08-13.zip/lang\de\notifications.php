<?php

return [
    'marked_as_read' => 'Benachrichtigung als gelesen markiert.',
    'sent'           => 'Benachrichtigung gesendet.',
];
