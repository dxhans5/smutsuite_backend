<?php

return [
    'marked_as_read' => 'Notificação marcada como lida.',
    'sent'           => 'Notificação enviada.',
];
