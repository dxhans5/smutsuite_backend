<?php

return [
    'sent'    => 'Mensaje enviado.',
    'deleted' => 'Mensaje eliminado.',
    'read'    => 'Mensaje marcado como leído.',
    'thread'  => [
        'fetched' => 'Hilo recuperado correctamente.',
    ],
];
