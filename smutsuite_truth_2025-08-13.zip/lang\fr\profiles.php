<?php

return [
    'public_updated'  => 'Profil public mis à jour.',
    'private_updated' => 'Profil privé mis à jour.',
    'fetched'         => 'Profil récupéré avec succès.',
];
