<?php

return [
    'registered'              => 'Account succesvol aangemaakt.',
    'logged_in'               => 'Succesvol ingelogd.',
    'logged_out'              => 'Succesvol uitgelogd.',
    'email_verification_sent' => 'Verificatie-e-mail verzonden.',
    'email_verified'          => 'E-mail succesvol geverifieerd.',
    'invalid_credentials'     => 'Deze inloggegevens komen niet overeen met onze gegevens.',
    'unauthenticated'         => 'Niet geauthenticeerd.',
];
