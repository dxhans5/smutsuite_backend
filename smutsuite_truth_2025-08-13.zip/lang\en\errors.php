<?php

return [
    'no_active_identity' => 'No active identity selected.',
    'forbidden'          => 'You are not authorized to perform this action.',
    'not_found'          => 'The requested resource was not found.',
    'server_error'       => 'Something went wrong. Please try again.',
];
