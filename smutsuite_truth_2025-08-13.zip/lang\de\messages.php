<?php

return [
    'sent'    => 'Nachricht gesendet.',
    'deleted' => 'Nachricht gelöscht.',
    'read'    => 'Nachricht als gelesen markiert.',
    'thread'  => [
        'fetched' => 'Thread erfolgreich abgerufen.',
    ],
];
