<?php

return [
    'save'   => 'Opslaan',
    'cancel' => 'Annuleren',
    'delete' => 'Verwijderen',
    'edit'   => 'Bewerken',
    'update' => 'Bijwerken',
    'create' => 'Aanmaken',
    'back'   => 'Terug',
    'search' => 'Zoeken',
    'loading'=> 'Laden...',
    'success'=> 'Succes',
    'error'  => 'Fout',
];
