<?php

return [
    'public_updated'  => 'Perfil público atualizado.',
    'private_updated' => 'Perfil privado atualizado.',
    'fetched'         => 'Perfil recuperado com sucesso.',
];
