<?php

return [
    'save'   => 'Guardar',
    'cancel' => 'Cancelar',
    'delete' => 'Eliminar',
    'edit'   => 'Editar',
    'update' => 'Actualizar',
    'create' => 'Crear',
    'back'   => 'Atrás',
    'search' => 'Buscar',
    'loading'=> 'Cargando...',
    'success'=> 'Éxito',
    'error'  => 'Error',
];
