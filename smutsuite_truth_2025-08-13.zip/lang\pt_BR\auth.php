<?php

return [
    'registered'              => 'Conta criada com sucesso.',
    'logged_in'               => 'Login realizado com sucesso.',
    'logged_out'              => 'Logout realizado com sucesso.',
    'email_verification_sent' => 'E-mail de verificação enviado.',
    'email_verified'          => 'E-mail verificado com sucesso.',
    'invalid_credentials'     => 'Essas credenciais não correspondem aos nossos registros.',
    'unauthenticated'         => 'Não autenticado.',
];
