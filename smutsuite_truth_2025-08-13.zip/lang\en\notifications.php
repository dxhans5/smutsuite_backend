<?php

return [
    'marked_as_read' => 'Notification marked as read.',
    'sent'           => 'Notification sent.',
];
