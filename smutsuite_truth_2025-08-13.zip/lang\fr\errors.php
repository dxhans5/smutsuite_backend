<?php

return [
    'no_active_identity' => 'Aucune identité active sélectionnée.',
    'forbidden'          => 'Vous n’êtes pas autorisé à effectuer cette action.',
    'not_found'          => 'La ressource demandée est introuvable.',
    'server_error'       => 'Un problème est survenu. Veuillez réessayer.',
];
