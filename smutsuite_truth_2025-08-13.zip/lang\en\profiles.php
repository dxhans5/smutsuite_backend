<?php

return [
    'public_updated'  => 'Public profile updated.',
    'private_updated' => 'Private profile updated.',
    'fetched'         => 'Profile retrieved successfully.',
];
