<?php

return [
    'no_active_identity' => 'No se ha seleccionado ninguna identidad activa.',
    'forbidden'          => 'No estás autorizado para realizar esta acción.',
    'not_found'          => 'No se encontró el recurso solicitado.',
    'server_error'       => 'Algo salió mal. Por favor, inténtalo de nuevo.',
];
