<?php

return [
    'save'   => 'Enregistrer',
    'cancel' => 'Annuler',
    'delete' => 'Supprimer',
    'edit'   => 'Modifier',
    'update' => 'Mettre à jour',
    'create' => 'Créer',
    'back'   => 'Retour',
    'search' => 'Rechercher',
    'loading'=> 'Chargement...',
    'success'=> 'Succès',
    'error'  => 'Erreur',
];
