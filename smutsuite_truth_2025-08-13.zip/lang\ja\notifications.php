<?php

return [
    'marked_as_read' => '通知を既読にしました。',
    'sent'           => '通知を送信しました。',
];
