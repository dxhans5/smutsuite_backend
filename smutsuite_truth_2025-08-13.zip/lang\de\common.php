<?php

return [
    'save'   => 'Speichern',
    'cancel' => 'Abbrechen',
    'delete' => 'Löschen',
    'edit'   => 'Bearbeiten',
    'update' => 'Aktualisieren',
    'create' => 'Erstellen',
    'back'   => 'Zurück',
    'search' => 'Suchen',
    'loading'=> 'Wird geladen...',
    'success'=> 'Erfolg',
    'error'  => 'Fehler',
];
