<?php

return [
    'sent'      => 'Message sent.',
    'deleted'   => 'Message deleted.',
    'read'      => 'Message marked as read.',
    'thread'    => [
        'fetched' => 'Thread retrieved successfully.',
    ],
];
