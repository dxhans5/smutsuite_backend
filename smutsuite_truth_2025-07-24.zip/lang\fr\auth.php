<?php

return [
    'failed' => 'Les informations d’identification sont incorrectes.',
    'login_success' => 'Connexion réussie.',
    'logout_success' => 'Déconnexion réussie.',
    'logged_out' => 'Vous avez été déconnecté avec succès.',
    'unauthenticated' => 'Non authentifié.',
];
