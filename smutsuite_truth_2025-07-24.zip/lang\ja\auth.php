<?php

return [
    'failed' => '認証情報が正しくありません。',
    'login_success' => 'ログインに成功しました。',
    'logout_success' => 'ログアウトしました。',
    'logged_out' => '正常にログアウトしました。',
    'unauthenticated' => '認証されていません。',
];
