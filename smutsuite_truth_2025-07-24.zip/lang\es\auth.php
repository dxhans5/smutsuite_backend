<?php

return [
    'failed' => 'Las credenciales proporcionadas son incorrectas.',
    'login_success' => 'Inicio de sesión exitoso.',
    'logout_success' => 'Cierre de sesión exitoso.',
];
