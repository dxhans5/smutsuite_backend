<?php

return [
    'public_updated'  => 'Perfil público actualizado.',
    'private_updated' => 'Perfil privado actualizado.',
    'fetched'         => 'Perfil recuperado correctamente.',
];
