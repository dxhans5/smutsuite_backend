<?php

return [
    'registered'              => 'Cuenta creada con éxito.',
    'logged_in'               => 'Has iniciado sesión correctamente.',
    'logged_out'              => 'Has cerrado sesión correctamente.',
    'email_verification_sent' => 'Correo de verificación enviado.',
    'email_verified'          => 'Correo electrónico verificado con éxito.',
    'invalid_credentials'     => 'Estas credenciales no coinciden con nuestros registros.',
    'unauthenticated'         => 'No autenticado.',
];
