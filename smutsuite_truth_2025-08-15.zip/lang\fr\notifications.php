<?php

return [
    'marked_as_read' => 'Notification marquée comme lue.',
    'sent'           => 'Notification envoyée.',
];
