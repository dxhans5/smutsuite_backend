<?php

return [
    'public_updated'  => '公開プロフィールを更新しました。',
    'private_updated' => '非公開プロフィールを更新しました。',
    'fetched'         => 'プロフィールを正常に取得しました。',
];
