<?php

return [
    'sent'    => 'Bericht verzonden.',
    'deleted' => 'Bericht verwijderd.',
    'read'    => 'Bericht als gelezen gemarkeerd.',
    'thread'  => [
        'fetched' => 'Thread succesvol opgehaald.',
    ],
];
