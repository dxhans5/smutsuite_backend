<?php

return [
    'sent'    => 'Mensagem enviada.',
    'deleted' => 'Mensagem excluída.',
    'read'    => 'Mensagem marcada como lida.',
    'thread'  => [
        'fetched' => 'Conversa recuperada com sucesso.',
    ],
];
