<?php

return [
    'save'   => 'Save',
    'cancel' => 'Cancel',
    'delete' => 'Delete',
    'edit'   => 'Edit',
    'update' => 'Update',
    'create' => 'Create',
    'back'   => 'Back',
    'search' => 'Search',
    'loading'=> 'Loading...',
    'success'=> 'Success',
    'error'  => 'Error',
];
