<?php

return [
    'marked_as_read' => 'Melding als gelezen gemarkeerd.',
    'sent'           => 'Melding verzonden.',
];
