<?php

return [
    'listed'          => 'Identiteiten opgehaald.',
    'created'         => 'Identiteit aangemaakt.',
    'updated'         => 'Identiteit bijgewerkt.',
    'deleted'         => 'Identiteit verwijderd.',
    'switched'        => 'Actieve identiteit gewijzigd.',
    'limit_reached'   => 'Limiet voor identiteiten bereikt.',
    'cooldown_active' => 'Wacht nog :hours uur voordat je een andere identiteit aanmaakt.',
    'not_found'       => 'Identiteit niet gevonden.',
    'forbidden'       => 'Je mag geen toegang krijgen tot deze identiteit.',
];
