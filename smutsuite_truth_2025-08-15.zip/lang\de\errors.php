<?php

return [
    'no_active_identity' => 'Keine aktive Identität ausgewählt.',
    'forbidden'          => 'Sie sind nicht berechtigt, diese Aktion auszuführen.',
    'not_found'          => 'Die angeforderte Ressource wurde nicht gefunden.',
    'server_error'       => 'Etwas ist schiefgelaufen. Bitte versuchen Sie es erneut.',
];
