<?php

return [
    'sent'    => 'Message envoyé.',
    'deleted' => 'Message supprimé.',
    'read'    => 'Message marqué comme lu.',
    'thread'  => [
        'fetched' => 'Fil de discussion récupéré avec succès.',
    ],
];
