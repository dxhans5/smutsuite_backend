<?php

return [
    'registered'              => 'Compte créé avec succès.',
    'logged_in'               => 'Connexion réussie.',
    'logged_out'              => 'Déconnexion réussie.',
    'email_verification_sent' => 'E-mail de vérification envoyé.',
    'email_verified'          => 'E-mail vérifié avec succès.',
    'invalid_credentials'     => 'Ces identifiants ne correspondent pas à nos enregistrements.',
    'unauthenticated'         => 'Non authentifié.',
];
