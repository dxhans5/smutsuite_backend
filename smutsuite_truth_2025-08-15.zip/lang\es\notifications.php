<?php

return [
    'marked_as_read' => 'Notificación marcada como leída.',
    'sent'           => 'Notificación enviada.',
];
