<?php

return [
    'permission_attach_success'   => 'Machtiging toegewezen.',
    'permission_detach_success'   => 'Machtiging verwijderd.',
    'permission_already_attached' => 'Machtiging is al toegewezen.',
    'permission_not_attached'     => 'Machtiging niet gevonden bij gebruiker.',
    'role_attach_success'         => 'Rol toegewezen.',
    'role_detach_success'         => 'Rol verwijderd.',
    'role_not_found'              => 'Rol niet gevonden.',
    'bulk_assign_success'         => 'Rollen en machtigingen succesvol toegewezen.',
    'bulk_remove_success'         => 'Rollen en machtigingen succesvol verwijderd.',
];
