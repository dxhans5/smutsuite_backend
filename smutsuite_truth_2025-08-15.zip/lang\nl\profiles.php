<?php

return [
    'public_updated'  => 'Openbaar profiel bijgewerkt.',
    'private_updated' => 'Privéprofiel bijgewerkt.',
    'fetched'         => 'Profiel succesvol opgehaald.',
];
