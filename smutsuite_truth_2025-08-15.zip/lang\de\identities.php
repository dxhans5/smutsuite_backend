<?php

return [
    'listed'          => 'Identitäten abgerufen.',
    'created'         => 'Identität erstellt.',
    'updated'         => 'Identität aktualisiert.',
    'deleted'         => 'Identität gelöscht.',
    'switched'        => 'Aktive Identität gewechselt.',
    'limit_reached'   => 'Identitätslimit erreicht.',
    'cooldown_active' => 'Bitte warten Sie noch :hours Stunde(n), bevor Sie eine weitere Identität erstellen.',
    'not_found'       => 'Identität nicht gefunden.',
    'forbidden'       => 'Sie dürfen auf diese Identität nicht zugreifen.',
];
