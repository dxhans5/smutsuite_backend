<?php

return [
    'permission_attach_success' => 'Toestemming gekoppeld.',
    'permission_detach_success' => 'Toestemming ontkoppeld.',
    'permission_already_attached' => 'Toestemming is al gekoppeld.',
    'permission_not_attached' => 'Toestemming niet gevonden bij gebruiker.',
    'role_attach_success' => 'Rol gekoppeld.',
    'role_detach_success' => 'Rol ontkoppeld.',
    'role_not_found' => 'Rol niet gevonden.',
    'bulk_assign_success' => 'Rollen en toestemmingen succesvol toegewezen.',
    'bulk_remove_success' => 'Rollen en toestemmingen succesvol verwijderd.',
];
