<?php

return [
    'permission_attach_success' => 'Permission attribuée.',
    'permission_detach_success' => 'Permission retirée.',
    'permission_already_attached' => 'La permission est déjà attribuée.',
    'permission_not_attached' => 'Permission non attribuée à l’utilisateur.',
    'role_attach_success' => 'Rôle attribué.',
    'role_detach_success' => 'Rôle retiré.',
    'role_not_found' => 'Rôle introuvable.',
    'bulk_assign_success' => 'Rôles et permissions attribués avec succès.',
    'bulk_remove_success' => 'Rôles et permissions retirés avec succès.',
];
