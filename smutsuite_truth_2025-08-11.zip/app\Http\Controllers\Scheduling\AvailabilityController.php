<?php

namespace App\Http\Controllers\Scheduling;

use App\Http\Controllers\Controller;
use App\Models\AvailabilityRule;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AvailabilityController extends Controller
{
    /**
     * Show availability for the currently active identity.
     */
    public function getMyAvailability(Request $request): JsonResponse
    {
        $identity = $request->currentIdentity();
        abort_unless($identity, 403, __('No active identity selected.'));

        $availability = AvailabilityRule::where('identity_id', $identity->id)->get();

        return response()->json([
            'data' => $availability
        ]);
    }

    /**
     * Update availability for the currently active identity.
     */
    public function updateMyAvailability(Request $request): JsonResponse
    {
        $identity = $request->currentIdentity();
        abort_unless($identity, 403, __('No active identity selected.'));

        $validator = Validator::make($request->all(), [
            'availability' => 'required|array',
            'availability.*.day_of_week'  => 'required|integer|between:0,6',
            'availability.*.start_time'   => 'required|date_format:H:i',
            'availability.*.end_time'     => 'required|date_format:H:i',
            'availability.*.booking_type' => 'required|string',
        ]);

        $validator->after(function ($v) use ($request) {
            foreach ($request->availability as $index => $rule) {
                if (isset($rule['start_time'], $rule['end_time']) &&
                    $rule['end_time'] <= $rule['start_time']) {
                    $v->errors()->add(
                        "availability.$index.end_time",
                        __('End time must be after start time.')
                    );
                }
            }
        });

        $validator->validate();

        AvailabilityRule::where('identity_id', $identity->id)->delete();

        foreach ($request->availability as $rule) {
            AvailabilityRule::create([
                'identity_id'  => $identity->id,
                'day_of_week'  => $rule['day_of_week'],
                'start_time'   => $rule['start_time'],
                'end_time'     => $rule['end_time'],
                'booking_type' => $rule['booking_type'],
                'is_active'    => true
            ]);
        }

        return response()->json([
            'data' => ['message' => __('Availability updated.')]
        ]);
    }

    /**
     * Get availability for a specific identity (public-facing).
     */
    public function getUserAvailability(User $userOrLegacy, Request $request): JsonResponse
    {
        $identityId = $request->route('identity') ?? null;
        abort_unless($identityId, 404);

        $availability = AvailabilityRule::where('identity_id', $identityId)
            ->where('is_active', true)
            ->get();

        return response()->json([
            'data' => $availability
        ]);
    }
}
