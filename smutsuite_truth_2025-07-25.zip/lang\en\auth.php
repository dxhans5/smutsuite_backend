<?php

return [
    'failed' => 'The provided credentials are incorrect.',
    'login_success' => 'Login successful.',
    'logout_success' => 'Logged out successfully.',
    'logged_out' => 'You have been logged out successfully.',
    'unauthenticated' => 'Unauthenticated.',
];
