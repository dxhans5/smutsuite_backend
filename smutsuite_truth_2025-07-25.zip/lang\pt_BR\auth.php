<?php

return [
    'failed' => 'As credenciais fornecidas estão incorretas.',
    'login_success' => 'Login realizado com sucesso.',
    'logout_success' => 'Logout realizado com sucesso.',
    'logged_out' => 'Você saiu com sucesso.',
    'unauthenticated' => 'Não autenticado.',
];
