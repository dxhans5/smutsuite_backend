<?php

return [
    'failed' => 'De opgegeven inloggegevens zijn onjuist.',
    'login_success' => 'Succesvol ingelogd.',
    'logout_success' => 'Succesvol uitgelogd.',
    'logged_out' => 'U bent succesvol uitgelogd.',
    'unauthenticated' => 'Niet geauthenticeerd.',
];
