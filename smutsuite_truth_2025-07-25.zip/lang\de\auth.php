<?php

return [
    'failed' => 'Die angegebenen Zugangsdaten sind falsch.',
    'login_success' => 'Anmeldung erfolgreich.',
    'logout_success' => 'Erfolgreich abgemeldet.',
    'logged_out' => 'Sie wurden erfolgreich abgemeldet.',
    'unauthenticated' => 'Nicht authentifiziert.',
];
